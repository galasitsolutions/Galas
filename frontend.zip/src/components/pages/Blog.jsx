import blogImg from "../../assets/img/product/work.webp";
import MainLayout from "../layout/MainLayout";
import React from "react";


const Blog = () => {
  return (
    <>
      <MainLayout>
        <div className="section-space"></div>
        <section className="container mx-auto px-4 flex gap-10 flex-col lg:flex-row justify-center items-stretch">
          <div className="info-box flex items-center">
            <article className="content flex flex-col items-center text-center gap-6">
              <p className="section-title p-4r"> <span className="line bg-blue-800 font-semibold"></span>OUR BLOGS</p>
              <h2 id="hero-heading" className=" font-heading font-semibold  mb-4"> We re{" "}
                <span style={{ color: "#2563eb" }}>Bridging Talented<br></br> Vision for</span>{" "}
                Unmatched Success</h2>
            </article>
          </div>
          <div className="blog">
          </div>
        </section>
        <section className="container mx-auto px-4 flex gap-10 flex-col lg:flex-row justify-start items-stretch">
          <div className="section-space"></div>
          <div className="content flex flex-row items-center text-center gap-10"><br></br>
            <div className="content flex flex-row items-center text-start gap-10">
              <div className="content flex flex-col items-center text-start gap-10"> 
                <img
                  src={blogImg}
                  alt="blog image showcasing companies description"
                  className="rounded-2xl object-cover shadow-sm h-full sm:h-[50vh] md:h-[50vh]"
                  loading="lazy"
                  width={700}
                  height={700}
                />
                <p className=" font-heading font-semibold  mb-4"><a href=""> We re{" "}
                  <span style={{ color: "#2563eb" }}>Bridging Talented<br></br> Vision for</span>{" "}<br></br>
                  Unmatched Success</a></p>
              </div>
            </div>

            <div className="content flex flex-col text-center gap-6">
              <div>
                <div className="content flex flex-row items-center text-center gap-1">
                  <img
                    src={blogImg}
                    alt="blog image showcasing companies Blogs"
                    className="rounded-2xl object-cover  shadow-sm sm:h-[15vh] md:h-[15vh]"
                    loading="lazy"
                    width={150}
                    height={100}
                  />
                  <h6><a href="">blog description</a></h6>
                </div>
                <br></br>
                <div className="content flex flex-row items-center text-center gap-1">
                  <img
                    src={blogImg}
                    alt="blog image showcasing companies Blogs"
                    className="rounded-2xl object-cover  shadow-sm sm:h-[15vh] md:h-[15vh]"
                    loading="lazy"
                    width={150}
                    height={100}
                  />
                  <h6><a href="">blog description</a></h6>
                </div>
                  <br></br>
                <div className="content flex flex-row items-center text-center gap-1">
                  <img
                    src={blogImg}
                    alt="blog image showcasing companies Blogs"
                    className="rounded-2xl object-cover  shadow-sm sm:h-[15vh] md:h-[15vh]"
                    loading="lazy"
                    width={150}
                    height={100}
                  />
                  <h6><a href="">blog description</a></h6>
                </div>
              </div>
            </div>
          </div>
        </section>
      </MainLayout>
    </>
  );
};

export default Blog;
